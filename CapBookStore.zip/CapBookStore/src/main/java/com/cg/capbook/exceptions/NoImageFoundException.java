package com.cg.capbook.exceptions;

public class NoImageFoundException extends Exception{

	public NoImageFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoImageFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoImageFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoImageFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoImageFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
